/*Aufgabe: (Semesteraufgabe)
Name: (Sara Kalinic)
Matrikel: (255073)
Datum: (16.07.2017)
Hiermit versichere ich, dass ich diesen
Code selbst geschrieben habe. Er wurde
nicht kopiert und auch nicht diktiert. */

namespace Sem {

    export class AmeiseBrown extends Ameise {
 

        constructor() {
            super();
            this.color = "brown"; 

        }

      }
}